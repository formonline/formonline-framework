tinyMCE.addI18n('en.codeprotect',{
	desc : 'This plugin will protect PHP tags from being stripped'
});
